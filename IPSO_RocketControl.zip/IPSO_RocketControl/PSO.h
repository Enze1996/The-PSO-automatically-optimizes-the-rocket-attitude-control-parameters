#ifndef PSO_H
#define PSO_H

#include <vector>
#include <functional>
#include <limits>       // ��������ֵ���͵�������ص���Ϣ���������ֵ����Сֵ�����ȵ�
 
class PSO 
{
public:
    PSO(int num_particles, int num_dimensions, std::function<double(std::vector<double>)> objective_func);
    void optimize(int max_iterations);

    std::vector<double> get_best_solution() const;
    double get_best_value() const;

private:
    int num_particles;
    int num_dimensions;
    std::function<double(std::vector<double>)> objective_func;

    std::vector<std::vector<double>> particles;  // Particles' positions
    std::vector<std::vector<double>> velocities; // Particles' velocities
    std::vector<double> personal_best_values;    // Personal best values of particles
    std::vector<std::vector<double>> personal_best_positions; // Personal best positions of particles
    std::vector<double> global_best_position;    // Global best position
    double global_best_value;                    // Global best value

    double inertia_weight;
    double cognitive_component;
    double social_component;

    void initialize_particles();
    void update_particles();
    void update_personal_and_global_best();
};

#endif
