#include "PSO.h"
#include <iostream>
#include <random>
#include <limits>
#include <algorithm>

PSO::PSO(int num_particles, int num_dimensions, std::function<double(std::vector<double>)> objective_func)
    : num_particles(num_particles), num_dimensions(num_dimensions), objective_func(objective_func),
    inertia_weight(0.7), cognitive_component(1.5), social_component(1.5),
    global_best_value(std::numeric_limits<double>::infinity()) {
    initialize_particles();
}

void PSO::initialize_particles() {
    particles.resize(num_particles, std::vector<double>(num_dimensions));
    velocities.resize(num_particles, std::vector<double>(num_dimensions));
    personal_best_values.resize(num_particles, std::numeric_limits<double>::infinity());
    personal_best_positions.resize(num_particles, std::vector<double>(num_dimensions));
    global_best_position.resize(num_dimensions);  // ��ʼ�� global_best_position

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(-10.0, 10.0); // Particle position range

    // Initialize particles and velocities
    for (int i = 0; i < num_particles; i++) {
        for (int j = 0; j < num_dimensions; j++) {
            particles[i][j] = dis(gen);
            velocities[i][j] = dis(gen);
        }
    }
}

void PSO::update_particles() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(0.0, 1.0);

    for (int i = 0; i < num_particles; i++) {
        for (int j = 0; j < num_dimensions; j++) {
            // Update velocity
            velocities[i][j] = inertia_weight * velocities[i][j] +
                cognitive_component * dis(gen) * (personal_best_positions[i][j] - particles[i][j]) +
                social_component * dis(gen) * (global_best_position[j] - particles[i][j]);

            // Update position
            particles[i][j] += velocities[i][j];
        }
    }
}

void PSO::update_personal_and_global_best() {
    for (int i = 0; i < num_particles; i++) {
        double current_value = objective_func(particles[i]);

        // Update personal best
        if (current_value < personal_best_values[i]) {
            personal_best_values[i] = current_value;
            personal_best_positions[i] = particles[i];
        }

        // Update global best
        if (current_value < global_best_value) {
            global_best_value = current_value;
            global_best_position = particles[i];  // Update global best position
        }
    }
}

void PSO::optimize(int max_iterations) {
    for (int iteration = 0; iteration < max_iterations; iteration++) {
        update_particles();
        update_personal_and_global_best();

        std::cout << "Iteration " << iteration << ": Best Value = " << global_best_value << std::endl;
    }
}

std::vector<double> PSO::get_best_solution() const {
    return global_best_position;
}

double PSO::get_best_value() const {
    return global_best_value;
}
